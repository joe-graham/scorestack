"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ScorestackPlugin = void 0;

var _routes = require("./routes");

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class ScorestackPlugin {
  constructor(initializerContext) {
    _defineProperty(this, "logger", void 0);

    this.logger = initializerContext.logger.get();
  }

  setup(core) {
    this.logger.debug('scorestack: Setup');
    const router = core.http.createRouter(); // Register server side APIs

    (0, _routes.defineRoutes)(router, core.elasticsearch.legacy.client);
    return {};
  }

  start(core) {
    this.logger.debug('scorestack: Started');
    return {};
  }

  stop() {
    this.logger.debug('scorestack: Stopped');
  }

}

exports.ScorestackPlugin = ScorestackPlugin;