"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.plugin = plugin;
Object.defineProperty(exports, "ScorestackPluginSetup", {
  enumerable: true,
  get: function () {
    return _types.ScorestackPluginSetup;
  }
});
Object.defineProperty(exports, "ScorestackPluginStart", {
  enumerable: true,
  get: function () {
    return _types.ScorestackPluginStart;
  }
});

var _plugin = require("./plugin");

var _types = require("./types");

//  This exports static code and TypeScript types,
//  as well as, Kibana Platform `plugin()` initializer.
function plugin(initializerContext) {
  return new _plugin.ScorestackPlugin(initializerContext);
}