import React from 'react';
import ReactDOM from 'react-dom';
import { ScorestackApp } from './components/app';
export var renderApp = function renderApp(_ref, _ref2, _ref3) {
  var notifications = _ref.notifications,
      http = _ref.http;
  var navigation = _ref2.navigation;
  var appBasePath = _ref3.appBasePath,
      element = _ref3.element;
  ReactDOM.render( /*#__PURE__*/React.createElement(ScorestackApp, {
    basename: appBasePath,
    http: http
  }), element);
  return function () {
    return ReactDOM.unmountComponentAtNode(element);
  };
};