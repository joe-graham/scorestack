function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

import { PLUGIN_NAME } from '../common';
export var ScorestackPlugin = /*#__PURE__*/function () {
  function ScorestackPlugin() {
    _classCallCheck(this, ScorestackPlugin);
  }

  _createClass(ScorestackPlugin, [{
    key: "setup",
    value: function setup(core) {
      // Register an application into the side navigation menu
      core.application.register({
        id: 'scorestack',
        title: PLUGIN_NAME,
        mount: function mount(params) {
          return _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _yield$import, renderApp, _yield$core$getStartS, _yield$core$getStartS2, coreStart, depsStart;

            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return import('./application');

                  case 2:
                    _yield$import = _context.sent;
                    renderApp = _yield$import.renderApp;
                    _context.next = 6;
                    return core.getStartServices();

                  case 6:
                    _yield$core$getStartS = _context.sent;
                    _yield$core$getStartS2 = _slicedToArray(_yield$core$getStartS, 2);
                    coreStart = _yield$core$getStartS2[0];
                    depsStart = _yield$core$getStartS2[1];
                    return _context.abrupt("return", renderApp(coreStart, depsStart, params));

                  case 11:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee);
          }))();
        }
      }); // Return methods that should be available to other plugins

      return {};
    }
  }, {
    key: "start",
    value: function start(core) {
      return {};
    } // eslint-disable-next-line prettier/prettier

  }, {
    key: "stop",
    value: function stop() {}
  }]);

  return ScorestackPlugin;
}();