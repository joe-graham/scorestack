function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

import { EuiPage, EuiPageBody, EuiPageContent, EuiPageContentBody, EuiPageContentHeader, EuiPageContentHeaderSection, EuiPageSideBar, EuiSideNav, EuiText, EuiTitle } from '@elastic/eui';
import React, { Fragment, useEffect, useState } from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import { Attribute } from './attribute';
var initialNavItems = [{
  name: 'Loading...',
  id: 'loading'
}];
export function ScorestackApp(props) {
  var _useState = useState(initialNavItems),
      _useState2 = _slicedToArray(_useState, 2),
      navItems = _useState2[0],
      setNavItems = _useState2[1];

  var _useState3 = useState( /*#__PURE__*/React.createElement(EuiText, null, "Click on any of your checks to the left to configure their attributes.")),
      _useState4 = _slicedToArray(_useState3, 2),
      focusedContent = _useState4[0],
      setFocusedContent = _useState4[1];

  useEffect(function () {
    props.http.get('/api/scorestack/attribute').then(function (response) {
      // Construct nav headers from the group names
      var newNavItems = Object.entries(response).map(function (_ref) {
        var _ref2 = _slicedToArray(_ref, 2),
            groupName = _ref2[0],
            groupChecks = _ref2[1];

        // Construct nav items for each check within the group
        var subNavItems = Object.entries(groupChecks).map(function (_ref3) {
          var _ref4 = _slicedToArray(_ref3, 2),
              checkId = _ref4[0],
              check = _ref4[1];

          return {
            name: check.name,
            id: checkId,
            onClick: function onClick() {
              // Create the attributes that will be displayed on the page
              var attributes = Object.entries(check.attributes).map(function (_ref5) {
                var _ref6 = _slicedToArray(_ref5, 2),
                    name = _ref6[0],
                    value = _ref6[1];

                return /*#__PURE__*/React.createElement(Attribute, {
                  key: "".concat(checkId, "-").concat(name),
                  id: checkId,
                  name: name,
                  value: value,
                  http: props.http
                });
              }); // Set the new center content

              setFocusedContent( /*#__PURE__*/React.createElement(Fragment, null, /*#__PURE__*/React.createElement(EuiPageContentHeader, null, /*#__PURE__*/React.createElement(EuiPageContentHeaderSection, null, /*#__PURE__*/React.createElement(EuiTitle, null, /*#__PURE__*/React.createElement("h2", null, check.name)))), /*#__PURE__*/React.createElement(EuiPageContentBody, null, attributes)));
            }
          };
        });
        return {
          name: groupName,
          id: groupName,
          items: subNavItems
        };
      });
      setNavItems(newNavItems);
    }).catch(function (error) {
      // TODO: handle this with a toast

      /* eslint-disable no-console */
      console.log('Promise rejected - failed to load attributes');
      console.log(error);
      /* eslint-ensable no-console */
    });
  }, [props.http]);
  return /*#__PURE__*/React.createElement(Router, {
    basename: props.basename
  }, /*#__PURE__*/React.createElement(EuiPage, {
    restrictWidth: "1000px"
  }, /*#__PURE__*/React.createElement(EuiPageSideBar, null, /*#__PURE__*/React.createElement(EuiSideNav, {
    mobileTitle: "Checks",
    items: navItems
  })), /*#__PURE__*/React.createElement(EuiPageBody, null, /*#__PURE__*/React.createElement(EuiPageContent, null, focusedContent))));
}