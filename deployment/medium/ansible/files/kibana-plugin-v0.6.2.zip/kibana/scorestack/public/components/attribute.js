function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

import React, { useState } from 'react';
import { EuiFlexGroup, EuiFlexItem, EuiButtonIcon, EuiButton, EuiFormRow, EuiFieldText, EuiPopover, EuiText } from '@elastic/eui';
export function Attribute(props) {
  var _useState = useState(props.value),
      _useState2 = _slicedToArray(_useState, 2),
      value = _useState2[0],
      setValue = _useState2[1];

  var _useState3 = useState(''),
      _useState4 = _slicedToArray(_useState3, 2),
      formValue = _useState4[0],
      setFormValue = _useState4[1];

  var _useState5 = useState(false),
      _useState6 = _slicedToArray(_useState5, 2),
      visible = _useState6[0],
      setVisible = _useState6[1];

  var _useState7 = useState(false),
      _useState8 = _slicedToArray(_useState7, 2),
      loading = _useState8[0],
      setLoading = _useState8[1];

  var showButton = /*#__PURE__*/React.createElement(EuiButtonIcon, {
    iconType: "eye",
    onClick: function onClick() {
      return setVisible(!visible);
    }
  });

  function onSaveButtonClick() {
    // Start the loading spinner
    setLoading(true);
    props.http.post("/api/scorestack/attribute/".concat(props.id, "/").concat(props.name), {
      body: JSON.stringify({
        value: formValue
      }),
      headers: {
        'Content-Type': 'application/json'
      }
    }).then(function () {
      setLoading(false);
      setValue(formValue);
      setFormValue('');
    }).catch(function (error) {
      // TODO: handle this with a toast

      /* eslint-disable no-console */
      console.log('Promise rejected - failed to save attribute value');
      console.log(error);
      /* eslint-enable no-console */
    });
  }

  return /*#__PURE__*/React.createElement(EuiFlexGroup, {
    style: {
      maxWidth: 600
    }
  }, /*#__PURE__*/React.createElement(EuiFlexItem, null, /*#__PURE__*/React.createElement(EuiFormRow, {
    label: props.name
  }, /*#__PURE__*/React.createElement(EuiFieldText, {
    value: formValue,
    onChange: function onChange(event) {
      return setFormValue(event.target.value);
    }
  }))), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiFormRow, {
    hasEmptyLabelSpace: true
  }, /*#__PURE__*/React.createElement(EuiPopover, {
    id: "showValue",
    ownFocus: true,
    button: showButton,
    isOpen: visible,
    closePopover: function closePopover() {
      return setVisible(false);
    }
  }, /*#__PURE__*/React.createElement(EuiText, null, /*#__PURE__*/React.createElement("code", null, value))))), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiFormRow, {
    hasEmptyLabelSpace: true
  }, /*#__PURE__*/React.createElement(EuiButton, {
    isLoading: loading,
    onClick: onSaveButtonClick
  }, "Save"))));
}