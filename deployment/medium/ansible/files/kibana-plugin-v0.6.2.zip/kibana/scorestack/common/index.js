"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = 'scorestack';
exports.PLUGIN_ID = PLUGIN_ID;
const PLUGIN_NAME = 'scorestack';
exports.PLUGIN_NAME = PLUGIN_NAME;